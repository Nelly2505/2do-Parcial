package org.musicstore.dao;

public class BaseDAO {
}
