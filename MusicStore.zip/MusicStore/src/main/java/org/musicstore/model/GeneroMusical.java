package org.musicstore.model;

public class GeneroMusical extends Catalogo {
    public GeneroMusical() {}

    public GeneroMusical(int id, String descripcion) {
        super(id, descripcion);
    }
}
