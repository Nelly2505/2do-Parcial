package org.musicstore.model;

public class Artista extends Catalogo {
    public Artista() {}

    public Artista(int id, String nombre) {
        super(id, nombre);
    }
}
