package org.musicstore.model;

public class Disquera extends Catalogo {
    public Disquera() {}

    public Disquera(int id, String nombre) {
        super(id, nombre);
    }
}

